

p install virtualenv
```
1. create new virtual environment
```
py -m venv venv
```
2. activate the new virtual
```
.\venv\Scripts\activate
```
3. install requirements.txt
4. python manage.py migrate
```
pip install -r requirements.txt
```
4. run local server to begin
 ```
 py manage.py runserver
 ```
 5. go live with [localhost:8000](http://localhost:8000/)

 ## To add new products and access admin panel 
 1. run on trimnal 
 ```
 py manage.py createsuperuser
 ```
 2. create new admin user
 2. go to [localhost:8000/admin](http://localhost:8000/admin)


## Some of feature in this store

- Full-featured shopping cart
- Review and Rating System
- Top products carousel
- Product pagination
- Product search feature
- User profile with orders
- Admin product management
- Admin Order details page
- Mark orders as a delivered option
- Checkout process (shipping, payment method, etc... )
- PayPal / Credit Card integration
- Category Filter
- Addition of variable products    
- Post on your blog
- Contact page
- Professional and modern website design with matching colors
- An unlimited number of products and categories
- Unlimited pages 
- Easy to manage the site



#